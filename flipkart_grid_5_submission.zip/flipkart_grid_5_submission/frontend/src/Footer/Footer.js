import React from "react";

function Footer() {
  return <footer>
    <div class="footer-bottom">

      <div class="container">

        {/* <!-- <img src="./assets/images/payment.png" alt="payment method" class="payment-img"> --> */}

        <p class="copyright">
          Flipkart Grid 5.0, 2023
        </p>

      </div>

    </div>

  </footer>;
}

export default Footer;